package com.example.tictactoe.log

import android.util.Log

object D {
    fun d(message:String){
        Log.d("sardor","---->   $message   <----")
    }
}